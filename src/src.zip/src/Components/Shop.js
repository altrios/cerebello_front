


function Shop() {
  return (
    <div className="App">
      <h1>Shop</h1>
    </div>
  );
}

export default Shop;
