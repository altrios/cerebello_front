import Nav from './Nav';
import About from './Components/About';
import Shop from './Components/Shop';
import './App.css';
import { BrowserRouter as Router, Link, Switch, Route } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <Nav />
        <Switch>
        <Route path="/" exact component={Home}/>
        <Route path="/shop" component={Shop}/>
        <Route path="/about" component={About}/>
        </Switch>
        
      </div>
    </Router>

  );
}
const Home =()=>(
  <div>
    <h1>Home</h1>
  </div>
);

export default App;
