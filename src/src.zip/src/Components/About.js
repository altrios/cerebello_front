


function About() {
  return (
    <div className="App">
      <h1>About</h1>
    </div>
  );
}

export default About;
